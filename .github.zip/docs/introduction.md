# Página de Exemplo

Esta é uma página de exemplo para validar a navegação do MkDocs.

## O que esta página demonstra

- Menu lateral funcionando
- Navegação entre páginas
- Estrutura correta de arquivos
- Build e deploy sem erro

---

⬅️ Previous [Home](index.md)
